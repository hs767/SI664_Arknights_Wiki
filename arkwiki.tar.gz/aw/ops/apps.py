from django.apps import AppConfig


class OpsConfig(AppConfig):
    name = 'ops'
