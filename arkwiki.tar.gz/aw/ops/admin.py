from django.contrib import admin
from ops.models import Operator

# Register your models here.

admin.site.register(Operator)
